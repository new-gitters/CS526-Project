# Wildfire Dashboard

Wildfire dashboard for visualizing and predicting wildfires and their causes

## INSTRUCTIONS FOR RUNNING

1. Download the wildfire data from <https://www.kaggle.com/rtatman/188-million-us-wildfires>
2. Place the wildfire data file in the folder labled 'classifiers' and run the jupyter notebook inside of the classifiers folder
3. Move the wildfire data file to the home folder containing app.py
4. Run python index.py to start up the app
5. The app may take a few minutes and may crash the first few times something is clicked because of the large amount of data
but after a few tries, the website will continuously work without failure until it is closed. The website does work so if it
crashes in the first few minutes a few times, just leave it open and reload after a minute or two.

## apps

Contains all of the individual pages for the dashboard

## assets

Contains pictures used in the dashboard

## app.py

Holds the app info

## index.py

Starts up the app and calls the various pages in the apps folder

## stat-cost-data.csv

Data for economic_loss.py

## stat-freq-data.csv

Data for economic_loss.py

## wildfire_df.p

Pickled cleaned dataframe for pages in the apps folder
