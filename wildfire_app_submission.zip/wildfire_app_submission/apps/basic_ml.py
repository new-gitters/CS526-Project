import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import numpy as np
import dash_bootstrap_components as dbc
import sqlite3
import pickle
import plotly.graph_objects as go
from datetime import date
import datetime as dt

"""SINGLE PAGE CHANGE: comment out next line if running as single page"""
from app import app

"""SINGLE PAGE CHANGE: uncomment next line if running as single page"""
# app = dash.Dash(__name__, external_stylesheets=[dbc.themes.DARKLY])

cause_mapping =  {'Arson': 0, 'Campfire': 1, 'Children': 2, 'Debris Burning': 3, 
                  'Equipment Use': 4, 'Fireworks': 5, 'Lightning': 6, 
                  'Powerline': 7, 'Railroad': 8, 'Smoking': 9, 'Structure': 10}
cause_mapping_reverse = {v: k for k,v in cause_mapping.items()}
category_mapping_reverse = {1: "Natural", 2: "Accidental", 3: "Malicious"}
arson_mapping_reverse = {0: "Non-Malicious", 1: "Malicious"}
state_mapping =  {"AK": 0, "AL": 1, "AR": 2, "AZ": 3, "CA": 4, "CO": 5, "CT": 6, "DC": 7, "DE": 8, 
                "FL": 9, "GA": 10, "HI": 11, "IA": 12, "ID": 13, "IL": 14, "IN": 15, "KS": 16, 
                "KY": 17, "LA": 18, "MA": 19, "MD": 20, "ME": 21, "MI": 22, "MN": 23, "MO": 24, 
                "MS": 25, "MT": 26, "NC": 27, "ND": 28, "NE": 29, "NH": 30, "NJ": 31, "NM": 32, 
                "NV": 33, "NY": 34, "OH": 35, "OK": 36, "OR": 37, "PA": 38, "PR": 39, "RI": 40, 
                "SC": 41, "SD": 42, "TN": 43, "TX": 44, "UT": 45, "VA": 46, "VT": 47, "WA": 48, 
                "WI": 49, "WV": 50, "WY": 51}
state_mapping_reverse = {v: k for k,v in state_mapping.items()}
size_class_mapping = {"A": 0, "B": 1, "C": 2, "D": 3, "E": 4, "F": 5, "G": 6}
size_class_mapping_reverse = {v: k for k,v in size_class_mapping.items()}
dow_mapping = {"Monday": 0, "Tuesday": 1, "Wednesday": 2, "Thursday": 3, "Friday": 4, "Saturday": 5, "Sunday": 6}
dow_mapping_reverse = {v: k for k,v in dow_mapping.items()}

specific_basic = pickle.load(open("classifiers/specific_basic_rf.sav", "rb"))
group_basic = pickle.load(open("classifiers/group_basic_rf.sav", "rb"))
arson_basic = pickle.load(open("classifiers/arson_basic_rf.sav", "rb"))
specificity = [specific_basic, group_basic, arson_basic]

us_state_abbrev = {
    "Alabama": "AL",
    "Alaska": "AK",
    "Arizona": "AZ",
    "Arkansas": "AR",
    "California": "CA",
    "Colorado": "CO",
    "Connecticut": "CT",
    "Delaware": "DE",
    "District of Columbia": "DC",
    "Florida": "FL",
    "Georgia": "GA",
    "Hawaii": "HI",
    "Idaho": "ID",
    "Illinois": "IL",
    "Indiana": "IN",
    "Iowa": "IA",
    "Kansas": "KS",
    "Kentucky": "KY",
    "Louisiana": "LA",
    "Maine": "ME",
    "Maryland": "MD",
    "Massachusetts": "MA",
    "Michigan": "MI",
    "Minnesota": "MN",
    "Mississippi": "MS",
    "Missouri": "MO",
    "Montana": "MT",
    "Nebraska": "NE",
    "Nevada": "NV",
    "New Hampshire": "NH",
    "New Jersey": "NJ",
    "New Mexico": "NM",
    "New York": "NY",
    "North Carolina": "NC",
    "North Dakota": "ND",
    "Ohio": "OH",
    "Oklahoma": "OK",
    "Oregon": "OR",
    "Pennsylvania": "PA",
    "Rhode Island": "RI",
    "South Carolina": "SC",
    "South Dakota": "SD",
    "Tennessee": "TN",
    "Texas": "TX",
    "Utah": "UT",
    "Vermont": "VT",
    "Virginia": "VA",
    "Washington": "WA",
    "West Virginia": "WV",
    "Wisconsin": "WI",
    "Wyoming": "WY",
    "Puerto Rico": "PR"
}
abbrev_us_state = dict(map(reversed, us_state_abbrev.items()))

month_dict = {1: "January", 2: "February", 3: "March", 4: "April", 5: "May", 6: "June", 
              7: "July", 8: "August", 9: "September", 10: "October", 11: "November", 12: "December"}

colors = {
    'background': '#1F2630',
    'text': '#7FDBFF'
}

# con = sqlite3.connect("wildfire_data.sqlite")

# df = pd.read_sql_query("SELECT STATE, FIRE_YEAR, STAT_CAUSE_DESCR, FIRE_SIZE_CLASS, DISCOVERY_DATE from Fires", con)
# df["DATE"] = pd.to_datetime(df["DISCOVERY_DATE"] - pd.Timestamp(0).to_julian_date(), unit="D")
# df["MONTH"] = pd.DatetimeIndex(df["DATE"]).month
# df = df.drop(columns = ["DISCOVERY_DATE", "DATE"])

df = pd.read_pickle("wildfire_df.p")

"""
LAYOUT
"""
def get_layout():
  return(dbc.Container([
            dbc.Row([
                html.H3("Fire Prediction for Basic Users", style = {"color": "white",
                                                                    "margin-left": "15px"}
                )
            ]),
            html.Br(),
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardBody([
                            html.P(
                              "Select Specificity:", style = {"color": "white", "margin-bottom": "0px"}
                            ),
                            dcc.Dropdown(
                              id="slct_spec",
                              multi = False,
                              clearable = False,
                              style = {"display": True, 'color': '#212121'},
                              value = 0,
                              options = [
                                  {"label": "Specific Cause", "value": 0},
                                  {"label": "Categorized Cause", "value": 1},
                                  {"label": "Malicious Y/N", "value": 2}
                              ]),
                            html.Br(),
                            html.P(
                              "State:",  style = {"color": "white", "margin-bottom": "0px"}
                            ),
                            dcc.Dropdown(
                              id="slct_state",
                                            multi = False,
                                            clearable = False,
                                            style = {"display": True, 'color': '#212121'},
                                            value = 0,
                                            options = [{"label": abbrev_us_state[label], "value": value} for label, value in state_mapping.items()],
                                            className="dcc_compon"
                            ),
                            html.Br(),
                            html.P(
                              "Date:", style = {"color": "white", "margin-bottom": "0px"}
                            ),
                            dcc.DatePickerSingle(
                                id = 'slct_basic_date',
                                date = date.today(),
                                initial_visible_month=date.today(),
                                display_format='MMM Do, YY'
                            ),
                            html.Br(),
                            html.Br(),
                            html.Div("Predicted cause for fire:", style={'fontsize': 16}),
                            html.Div(id="basic_result", children = [], style={'color':'#ffa500', 'fontSize': 25})
                        ])
                    ], color="dark")
                ], width = 2),
                dbc.Col([
                    dbc.Card([
                        dbc.CardBody([
                            dcc.Graph(id = "month_line", hoverData = None,
                                      config = {"displayModeBar": False,
                                                "scrollZoom": False,
                                                "doubleClick": "reset",
                                                "showTips": False})
                        ])
                    ])
                ], width = 6),
                dbc.Col([
                    dbc.Card([
                        dbc.CardBody([
                            dcc.Graph(id = "month_pie",
                                      config = {"displayModeBar": False})
                        ])
                    ])
                ], width = 4)
           ])
         ], fluid=True)
  )

"""SINGLE PAGE CHANGE: change layout = ... to app.layout = ... if running as single page"""
layout = get_layout()

"""
CALLBACK
"""
@app.callback(
    [Output("basic_result", "children"),
     Output("month_line","figure")],
    [Input("slct_spec", "value"),
     Input("slct_state", "value"),
     Input("slct_basic_date", "date")]
)
def update_basic_graph(slct_spec, slct_state, slct_date):
    date_obj = dt.datetime.strptime(slct_date, "%Y-%m-%d")
    slct_month = int(date_obj.month)
    slct_year = int(date_obj.year)
    slct_day = int(dow_mapping[date_obj.strftime('%A')])
    result = int(specificity[slct_spec].predict([[slct_state, slct_month, slct_day, slct_year]])[0])
    if slct_spec == 0:
        result = cause_mapping_reverse[result]
    elif slct_spec == 1:
        result = category_mapping_reverse[result]
    else:
        result = arson_mapping_reverse[result]
    df_line = df[df["STATE"] == state_mapping_reverse[slct_state]]
    line_title = "Total fires in " + abbrev_us_state[state_mapping_reverse[slct_state]] + " by Month"
    df_line = df_line.MONTH.value_counts().rename_axis("Month").reset_index(name="Counts")
    df_line = df_line.sort_values(by=['Month'])
    fig_line = px.line(data_frame=df_line, x="Month", y="Counts")
    fig_scatter = px.scatter(data_frame=df_line, x="Month", y="Counts")
    fig_combined = go.Figure(data=fig_line.data + fig_scatter.data)
    fig_combined.update_layout(
                      plot_bgcolor=colors['background'],
                      paper_bgcolor=colors['background'],
                      font_color=colors['text'],
                      title=line_title,
                      xaxis = dict(tickmode='array',
                                   tickvals=[1,2,3,4,5,6,7,8,9,10,11,12],
                                   ticktext=['January', 'February', 'March', 'April', 
                                             'May', 'June', 'July', 'August', 'September', 
                                             'October', 'November', 'December']))
    fig_combined.update_traces(marker=dict(size=14))
    # result = "Predicted cause for fire: " + result
    print("basic graph update")
    return result, fig_combined


@app.callback(
    Output("month_pie", "figure"),
    [Input("month_line", "hoverData"),
    Input("slct_state", "value")],
    prevent_initial_call=True
)
def update_pie(hov_data, slct_state):
    df_pie = df[df["STATE"] == state_mapping_reverse[slct_state]]
    if hov_data is None:
        cur_month = 1
    else:
        cur_month = hov_data['points'][0]['x']
    df_pie = df_pie[df_pie["MONTH"] == cur_month]
    df_pie = df_pie.STAT_CAUSE_DESCR.value_counts().rename_axis('Cause').reset_index(name='Counts')
    pie_title = "Cause of Fires in " + abbrev_us_state[state_mapping_reverse[slct_state]] + " in " + month_dict[cur_month]
    fig_pie = px.pie(data_frame=df_pie, 
                     values="Counts", 
                     names="Cause",
                     title=pie_title)
    fig_pie.update_layout(
                      plot_bgcolor=colors['background'],
                      paper_bgcolor=colors['background'],
                      font_color=colors['text'],
                      autosize=True,
                      title={
                        'y':0.9,
                        'x':0.5,
                        'xanchor': 'center',
                        'yanchor': 'top'
                      })
    fig_pie.update_yaxes(automargin=True)
    print("pie chart update")
    return fig_pie

'''SINGLE PAGE CHANGE: uncomment next line if running as single page'''
# if __name__ == "__main__":
#     app.run_server(debug=True)